package com.tomato.model;

public class Reservation {
	int Rest_id;
	String restName;
	String restAddress;
	String restLoc;
	String restRating;
	String restDesc;
	String restCuisines;	
	
	public Reservation() {
		
	}
	
	public Reservation(int restid,String restname,String restloc,String restrating,String restdesc,String restCuisines,String restaddress) {
		this.Rest_id=restid;
		this.restName=restname;
		this.restAddress=restaddress;
		this.restRating=restrating;
		this.restDesc=restdesc;
		this.restCuisines=restCuisines;
		this.restLoc=restloc;
	}

	

	public String getRestAddress() {
		return restAddress;
	}

	public void setRestAddress(String restAddress) {
		this.restAddress = restAddress;
	}

	public int getRest_id() {
		return Rest_id;
	}

	public void setRest_id(int rest_id) {
		Rest_id = rest_id;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getRestLoc() {
		return restLoc;
	}

	public void setRestLoc(String restLoc) {
		this.restLoc = restLoc;
	}

	public String getRestRating() {
		return restRating;
	}

	public void setRestRating(String restRating) {
		this.restRating = restRating;
	}

	public String getRestDesc() {
		return restDesc;
	}

	public void setRestDesc(String restDesc) {
		this.restDesc = restDesc;
	}

	public String getRestCuisines() {
		return restCuisines;
	}

	public void setRestCuisines(String restCuisines) {
		this.restCuisines = restCuisines;
	}
}
