package com.tomato.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.tomato.model.Users;

public class UsersDao {
	
	Users usr = null;
    Connection con = null;
	Statement stmt = null;
	
	public Users getAllUsers(Users user) throws SQLException, ClassNotFoundException  {
		
		Class.forName("com.mysql.cj.jdbc.Driver"); 
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/users","root","admin");
		
		System.out.println("Connection success");
		try {
			stmt = con.createStatement();
			String sql = "SELECT name,password FROM users WHERE username='" + user.getUsername() + "'";
			System.out.println("Query :" + sql);
				ResultSet rs1 = stmt.executeQuery(sql);
				while (rs1.next()) {
				usr=new Users(user.getUsername(),user.getPassword());
			}} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {

						stmt.close();
					}

					if (con != null) {
						con.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			System.out.println("Returning");
			return usr;	
	}

}
