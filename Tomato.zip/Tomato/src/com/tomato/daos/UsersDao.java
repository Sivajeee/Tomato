package com.tomato.daos;

import com.tomato.model.Users;
import com.tomato.util.dbUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UsersDao {
	
	public Users getAllUsers(Users user) {
		 
		Users usr = null;
	    Connection conn = dbUtil.getConnection();
		Statement stmt = null;	
		try {
			stmt = conn.createStatement();
			String sql = "SELECT name,password FROM users WHERE name='" + user.getUsername() + "'";
			System.out.println("Query :" + sql);
			ResultSet rs1 = stmt.executeQuery(sql);
			while (rs1.next()) {
				usr=new Users(rs1.getString("name"),rs1.getString("password"));
			}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {

						stmt.close();
					}

					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			System.out.println("Returning");
			return usr;	
		}
	public int insertUsers(Users user) {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		String n1=dtf.format(now);		
		String n2=n1.substring(0, 10);
		Users usr =null;
		int i = 0;
		Connection con=dbUtil.getConnection();
		Statement stmt = null;		
		try {
			stmt = con.createStatement();			
			String sql = "INSERT INTO USERS " + "VALUES('" +user.getUsername()+"','"+user.getPassword()+"','"+n2+"')";			
			System.out.println("Query :" + sql);
			i=stmt.executeUpdate(sql);
			System.out.println("Insertion successfull");
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {

					stmt.close();
				}

				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("after insert Returning");
		return i;	
	}		
}