package com.tomato.daos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tomato.model.Reservation;
import com.tomato.util.dbUtil;

public class ReservationDao {
	
	public List<Reservation> getRestswithLoc(Reservation res) {
		 
		Reservation rsn = null;
	    Connection conn = dbUtil.getConnection();
		Statement stmt = null;
		
		List<Reservation> restlist= new ArrayList<Reservation>(); 
		
		try {
			stmt = conn.createStatement();
			String sql = "SELECT  REST_ID,rest_name,rest_loc,rest_rating,rest_desc,rest_cuisines,rest_address FROM restaurant WHERE rest_loc='" + res.getRestLoc() + "'";
			System.out.println("Query :" + sql);
			ResultSet rs1 = stmt.executeQuery(sql);
			while (rs1.next()) {
				rsn=new Reservation(rs1.getInt("rest_id"),rs1.getString("rest_name"),rs1.getString("rest_loc"),rs1.getString("rest_rating"),rs1.getString("rest_desc"), rs1.getString("rest_Cuisines"),rs1.getString("rest_address"));
				restlist.add(rsn);
			}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {

						stmt.close();
					}

					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			System.out.println("Returning");
			return restlist;	
		}
}
