package com.tomato.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.tomato.*;
import com.tomato.daos.ReservationDao;
import com.tomato.model.Reservation;

import jdk.nashorn.internal.ir.RuntimeNode.Request;


/**
 * Servlet implementation class FindRestaurantController
 */
@WebServlet("/FindRestaurantController")
public class FindRestaurantController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindRestaurantController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		RequestDispatcher dispatcher = null;
		System.out.println("In Get of Reservation Controller");
		if (request.getRequestURI().contains("FindRestaurant")) {
			//dispatcher = this.request.getContextPath().getRequestDispatcher("/Reservation.jsp");
			String s =request.getContextPath().concat("/FindRestaurant.jsp");
			response.sendRedirect(s);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		System.out.println("In Post of FindRestaurant Controller");
		
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/Results.jsp");
		
		String loc = request.getParameter("rloc");
		String rtype = request.getParameter("rtype");
		String rrate = request.getParameter("rrating");
		
		/*System.out.println("Selected Loc is" +loc);
		System.out.println("Selected type is" +rtype);
		System.out.println("selected rate is" +rrate);*/
		
		Reservation ran=new Reservation();
		ran.setRestLoc(loc);
		ReservationDao rdao=new ReservationDao();
		List<Reservation> rn=rdao.getRestswithLoc(ran);
		
		request.setAttribute("results", rn);
		request.setAttribute("msg", "Find restaurant details below:");
		
		dispatcher.forward(request, response);
		
		/*System.out.println("Restaurant ID:" +rn.getRest_id());
		System.out.println("Restaurant Name:" +rn.getRestName());
		System.out.println("Restaurant Loc:" +rn.getRestLoc());
		System.out.println("Restaurant Desc:" +rn.getRestDesc());
		System.out.println("Restaurant Rating:" +rn.getRestRating());
		System.out.println("Restaurant Cuisines:" +rn.getRestCuisines());*/
		
		 
		
		
		//if (loc != " " & type == " " & rate== " ") {
			
		//}
	}

	}
