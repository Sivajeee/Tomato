package com.tomato.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xml.internal.ws.message.FaultMessage;
import com.tomato.daos.UsersDao;
import com.tomato.model.Users;

import sun.security.validator.ValidatorException;

/**
 * Servlet implementation class SignUpController
 */
@WebServlet("/SignUpController")
public class SignUpController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//RequestDispatcher dispatcher = null;	
		//if (request.getRequestURI().contains("Signup")) {
			//dispatcher = this.request.getContextPath().getRequestDispatcher("/Tomato.jsp");
		//	String s =request.getContextPath().concat("/LoginSuccess.jsp");
		//	response.sendRedirect(s);
		//}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		System.out.println("In post method of Signup");
		String uname=request.getParameter("name");
		String pwd=request.getParameter("psw");
		String rpwd=request.getParameter("pswrepeat");
		
		Users user=new Users();
		user.setUsername(uname);
		user.setPassword(pwd);
		
		System.out.println("Registred values are");
		System.out.println("Name :" + uname);
		System.out.println("pwd :" + pwd);
		System.out.println("rpwd :" + rpwd);
		
		UsersDao ud=new UsersDao();
		int ur=ud.insertUsers(user);
				
		if (ur == 0) {
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/Tomato.jsp");
			request.setAttribute("msg", "Invalid details. Please enter correct details");
			dispatcher.forward(request, response);
		} else {			
			RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/Tomato.jsp");
			System.out.println(dispatcher);
			dispatcher.forward(request, response);					
		}
		
	}

}
