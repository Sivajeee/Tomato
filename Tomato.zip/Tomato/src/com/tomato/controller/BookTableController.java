package com.tomato.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BookTableController
 */
@WebServlet("/BookTableController")
public class BookTableController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookTableController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		RequestDispatcher dispatcher = null;
		System.out.println("In Get of BookTable Controller");
		if (request.getRequestURI().contains("BookTables")) {
			//dispatcher = this.request.getContextPath().getRequestDispatcher("/Reservation.jsp");
			String s =request.getContextPath().concat("/BookTables.jsp");
			response.sendRedirect(s);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		System.out.println("In Post of BookTable Controller");
		
		//RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/BookTables.jsp");
		//String s=this.getServletContext().getRequestDispatcher("/BookTables.jsp").toString();
		
		String ID= request.getParameter("restId");
		String RName=request.getParameter("restName");
		String Bname=request.getParameter("bname");
		String Bphone=request.getParameter("bphone");
		String Bemail=request.getParameter("bemail");
		String Bdate=request.getParameter("bdate");
		String Btime=request.getParameter("btime");
		String Bnoper=request.getParameter("bnoper");
		String Bcomments=request.getParameter("bcomments");
		
		System.out.println("Form values are:");
		System.out.println(Bname);
		System.out.println(Bphone);
		System.out.println(Bemail);
		System.out.println(Bdate);
		System.out.println(Btime);
		System.out.println(Bnoper);
		System.out.println(Bcomments);
		
				
		
		
		String s =request.getContextPath().concat("/BookTables.jsp");
		response.sendRedirect(s);						
				
		
		System.out.println("RestId is in BookTable :" +ID);
		System.out.println("Rest Name in BookTable is:" +RName);
		
		request.setAttribute("Rname", RName);
		
	}

}
