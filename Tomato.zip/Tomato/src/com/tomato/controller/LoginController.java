package com.tomato.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.tomato.daos.UsersDao;
import com.tomato.model.Users;

import javafx.scene.control.Alert;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		RequestDispatcher dispatcher = null;	
		if (request.getRequestURI().contains("Login")) {
			//dispatcher = this.request.getContextPath().getRequestDispatcher("/Tomato.jsp");
			String s =request.getContextPath().concat("/Tomato.jsp");
			response.sendRedirect(s);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("In post method");
		String uname=request.getParameter("name");
		String pwd=request.getParameter("password");		
		
		System.out.println("entered values are");
		System.out.println("Name" + uname);
		System.out.println("Pwd" + pwd);
		
		Users user=new Users();
		user.setUsername(uname);
		user.setPassword(pwd);
		
		UsersDao ud=new UsersDao();
			Users ur=ud.getAllUsers(user);
			if (ur == null ) {
				RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/Tomato.jsp");
				request.setAttribute("msg", "Invalid details. Please enter correct details");
				dispatcher.forward(request, response);
			} else {
				System.out.println("Password from table :" + ur.getPassword());
				System.out.println("Password from input " + pwd);
				if(pwd.equals(ur.getPassword())){
					System.out.println("Success");
					RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/LoginSuccess.jsp");
					dispatcher.forward(request, response);					
				}	else {
					RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/Tomato.jsp");				
					request.setAttribute("msg", "Invalid details. Please enter correct details");					
					dispatcher.forward(request, response);
				}
			}
		
		//doGet(request, response);
	}
}
